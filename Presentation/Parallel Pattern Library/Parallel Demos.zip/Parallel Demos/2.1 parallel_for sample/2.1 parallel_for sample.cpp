// 2.1 parallel_for sample.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ppl.h"
#include <iostream>
using namespace Concurrency;
using namespace std;

int iSum = 0;
void func1(int x)
{
	iSum += x;
}
int _tmain(int argc, _TCHAR* argv[])
{
	parallel_for(1, 100, 2, &func1);
	//parallel_for(1 , 100, [&] (int n) {iSum += n;});
	cout << iSum << endl;
	cout << "press any key to continue..." << endl;
	::getchar();
	return 0;
}

