
// 3.13 UI Thread-finishedView.h : interface of the CMy313UIThreadfinishedView class
//

#pragma once

typedef std::shared_ptr<Gdiplus::Bitmap> BitmapPtr;



class CMy313UIThreadfinishedView : public CView
{
protected: // create from serialization only
	CMy313UIThreadfinishedView();
	DECLARE_DYNCREATE(CMy313UIThreadfinishedView)

// Attributes
public:
	CMy313UIThreadfinishedDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CMy313UIThreadfinishedView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
   // Draws the Mandelbrot fractal to the specified Bitmap object.
   void DrawMandelbrot(BitmapPtr);

protected:
	ULONG_PTR m_gdiplusToken;
	Concurrency::task_group m_DrawingTasks;
	Concurrency::unbounded_buffer<BitmapPtr> m_MandelbrotImages;



// Generated message map functions
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT, int, int);
	afx_msg void OnSizing(UINT, LPRECT); 
	afx_msg void OnDestroy();
};

#ifndef _DEBUG  // debug version in 3.13 UI Thread-finishedView.cpp
inline CMy313UIThreadfinishedDoc* CMy313UIThreadfinishedView::GetDocument() const
   { return reinterpret_cast<CMy313UIThreadfinishedDoc*>(m_pDocument); }
#endif

