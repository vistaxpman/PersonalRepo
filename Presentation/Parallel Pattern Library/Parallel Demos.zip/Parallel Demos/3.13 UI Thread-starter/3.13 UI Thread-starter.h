
// 3.13 UI Thread-starter.h : main header file for the 3.13 UI Thread-starter application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CMy313UIThreadstarterApp:
// See 3.13 UI Thread-starter.cpp for the implementation of this class
//

class CMy313UIThreadstarterApp : public CWinAppEx
{
public:
	CMy313UIThreadstarterApp();


// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation
	BOOL  m_bHiColorIcons;

	virtual void PreLoadState();
	virtual void LoadCustomState();
	virtual void SaveCustomState();

	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CMy313UIThreadstarterApp theApp;
