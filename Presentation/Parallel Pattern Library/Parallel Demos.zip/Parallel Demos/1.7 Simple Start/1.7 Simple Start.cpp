// 1.7 Simple Start.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <ppl.h>
#include <time.h>
#include "Windows.h"
using namespace std;
using namespace Concurrency;

int _tmain(int argc, _TCHAR* argv[])
{
	long iSum = 0;
	time_t start, end;
	double diff;
	time(&start);
	parallel_for(1, 10000000, [&](int n){
		//iSum += n;
		InterlockedExchangeAdd(&iSum, n);
	}
	);
	time(&end);
	diff = difftime(end, start);
	cout << iSum <<endl;
	 printf( "\nProgram takes %6.0000000f seconds.\n", diff );
	::getchar();
}