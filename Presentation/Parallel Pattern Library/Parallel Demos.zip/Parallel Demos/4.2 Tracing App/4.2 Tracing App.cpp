// 4.2 Tracing App.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <ppl.h>

using namespace Concurrency;

int _tmain(int argc, _TCHAR* argv[])
{
   // Perform some parallel work. 
   // Event tracing is disabled at this point.
   parallel_for(0, 10000, [](int i) {
      // TODO: Perform work.
   });

   // Enable tracing for a second call to parallel_for.
   HRESULT hr = EnableTracing();

   if(S_OK == hr)
	   hr = S_OK;
   parallel_for(0, 10000, [](int i) {
      // TODO: Perform work.
   });   
   DisableTracing();
   ::getchar();
}


