// 1.4 Lambda-4.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <functional>
using namespace std;

int main()
{
   int i = 3;
   int j = 5;
   // The following lambda expression captures i by value and
   // j by reference.
   function<int (void)> f = [i, &j] {
	   return i + j; };

   i = 22;
   j = 44;
   cout << f() << endl;
   ::getchar();
}
