// 1.5 Lambda-5.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

// Negates each element in the vector object.
template <typename T> 
void negate_all(vector<T>& v)
{
    for_each(v.begin(), v.end(), [] (T& n) { n = -n; } );
}

// Prints to the console each element in the vector object.
template <typename T> 
void print_all(const vector<T>& v)
{
   for_each(v.begin(), v.end(), [] (const T& n) { cout << n << endl; } );
}

int main()
{
   // Create a vector of integers with a few initial elements.
   vector<int> v;
   v.push_back(34);
   v.push_back(-43);
   v.push_back(56);

   // Negate each element in the vector.
   negate_all(v);

   // Print each element in the vector.
   print_all(v);

   ::getchar();
}

